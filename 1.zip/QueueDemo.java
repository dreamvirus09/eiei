import java.util.*;
public class QueueDemo {
   public static void main(String args[]) {
      Queue q = new LinkedList();
      System.out.println("queue: " + q);
      showEnqueue(q, 42);
      showEnqueue(q, 66);
      showEnqueue(q, 22);
      showEnqueue(q, 55);
      showpeek(q);
      showpeek(q);      
      while (!q.isEmpty()) {
        showDequeue(q);
      }
   }
   static void showEnqueue(Queue q, int a) {
      q.offer(new Integer(a));
      System.out.println("enqueue(" + a + ")");
      System.out.println("queue: " + q);
   }

   static void showDequeue(Queue q) {
      System.out.print("dequeue -> ");
      Integer a = (Integer) q.poll();
      System.out.println(a);
      System.out.println("queue: " + q);
   }
   static void showpeek(Queue q) {
      System.out.print("peek -> ");
      Integer a = (Integer) q.peek();
      System.out.println(a);
      System.out.println("queue: " + q);
   }
}
